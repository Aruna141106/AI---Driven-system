import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { companyName, website, legalName } = await req.json();
    console.log('Enriching company:', companyName);

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY not configured');
    }

    // Step 1: Web search for company information
    const searchQuery = `${companyName} ${legalName || ''} South Africa smartphone financing business model revenue headquarters`;
    console.log('Search query:', searchQuery);

    const searchResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          {
            role: 'system',
            content: 'You are a business research assistant. Search the web and provide detailed, factual information about companies. Always cite your sources and indicate confidence levels.'
          },
          {
            role: 'user',
            content: `Research this South African company involved in smartphone financing:
            
Name: ${companyName}
Legal Name: ${legalName || 'Unknown'}
Website: ${website || 'Unknown'}

Please provide the following information:
1. Headquarters city
2. Year founded
3. Approximate employee count
4. Estimated annual revenue in USD
5. Business model (e.g., "Direct financing", "BNPL", "Retail + financing")
6. Types of financing offered (e.g., "Installment plans", "Lease-to-own", "BNPL")
7. Credit requirements (e.g., "No credit check", "Basic credit check", "Full credit check")
8. Average interest rate (if available)
9. Maximum financing amount in USD
10. Average term length in months
11. Current operational status

Format your response as JSON with these exact field names:
{
  "headquarters_city": "string or null",
  "founded_year": number or null,
  "employee_count": number or null,
  "annual_revenue_usd": number or null,
  "financing_volume_usd": number or null,
  "market_share_percentage": number or null,
  "business_model": "string or null",
  "financing_types": ["array", "of", "strings"] or null,
  "credit_requirements": "string or null",
  "avg_approval_rate": number or null,
  "avg_interest_rate": number or null,
  "max_financing_amount_usd": number or null,
  "avg_term_months": number or null,
  "status": "string or null",
  "confidence_score": number (0-100),
  "data_sources": ["array of sources"]
}

If information is not available, use null. The confidence_score should reflect how certain you are about the data (0-100).`
          }
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "extract_company_data",
              description: "Extract structured company data from research",
              parameters: {
                type: "object",
                properties: {
                  headquarters_city: { type: ["string", "null"] },
                  founded_year: { type: ["number", "null"] },
                  employee_count: { type: ["number", "null"] },
                  annual_revenue_usd: { type: ["number", "null"] },
                  financing_volume_usd: { type: ["number", "null"] },
                  market_share_percentage: { type: ["number", "null"] },
                  business_model: { type: ["string", "null"] },
                  financing_types: { type: ["array", "null"], items: { type: "string" } },
                  credit_requirements: { type: ["string", "null"] },
                  avg_approval_rate: { type: ["number", "null"] },
                  avg_interest_rate: { type: ["number", "null"] },
                  max_financing_amount_usd: { type: ["number", "null"] },
                  avg_term_months: { type: ["number", "null"] },
                  status: { type: ["string", "null"] },
                  confidence_score: { type: "number" },
                  data_sources: { type: "array", items: { type: "string" } }
                },
                required: ["confidence_score"],
                additionalProperties: false
              }
            }
          }
        ],
        tool_choice: { type: "function", function: { name: "extract_company_data" } }
      }),
    });

    if (!searchResponse.ok) {
      const errorText = await searchResponse.text();
      console.error('AI API error:', searchResponse.status, errorText);
      throw new Error(`AI API error: ${searchResponse.status}`);
    }

    const searchData = await searchResponse.json();
    console.log('AI response received');

    // Extract tool call result
    const toolCall = searchData.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) {
      throw new Error('No tool call in AI response');
    }

    const enrichedData = JSON.parse(toolCall.function.arguments);
    console.log('Enriched data extracted:', enrichedData);

    return new Response(
      JSON.stringify({
        success: true,
        data: enrichedData
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('Error in enrich-company function:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred'
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});