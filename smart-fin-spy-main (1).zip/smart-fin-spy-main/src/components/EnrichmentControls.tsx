import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Play, Download, Upload, RefreshCw } from "lucide-react";

export const EnrichmentControls = ({ onRefresh }: { onRefresh: () => void }) => {
  const { toast } = useToast();
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentCompany, setCurrentCompany] = useState("");

  const loadCsvData = async () => {
    try {
      const response = await fetch('/data/companies.csv');
      const text = await response.text();
      const lines = text.split('\n').filter(line => line.trim());
      const headers = lines[0].split(',');
      
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',');
        if (values.length < 4) continue;

        const company = {
          id: values[0],
          name: values[1],
          legal_name: values[2] || null,
          website: values[3] || null,
        };

        await supabase.from('companies').upsert(company, {
          onConflict: 'id'
        });
      }

      toast({
        title: "Data loaded",
        description: "CSV data has been loaded into the database",
      });
      onRefresh();
    } catch (error) {
      console.error('Error loading CSV:', error);
      toast({
        title: "Error",
        description: "Failed to load CSV data",
        variant: "destructive",
      });
    }
  };

  const enrichAllCompanies = async () => {
    setProcessing(true);
    setProgress(0);

    try {
      const { data: companies, error } = await supabase
        .from('companies')
        .select('*')
        .or('enrichment_status.is.null,enrichment_status.eq.pending');

      if (error) throw error;
      if (!companies || companies.length === 0) {
        toast({
          title: "No companies to enrich",
          description: "All companies have been processed",
        });
        setProcessing(false);
        return;
      }

      for (let i = 0; i < companies.length; i++) {
        const company = companies[i];
        setCurrentCompany(company.name);
        setProgress(((i + 1) / companies.length) * 100);

        // Update status to processing
        await supabase
          .from('companies')
          .update({ enrichment_status: 'processing' })
          .eq('id', company.id);

        // Call enrichment function
        const { data: enrichData, error: enrichError } = await supabase.functions.invoke(
          'enrich-company',
          {
            body: {
              companyName: company.name,
              website: company.website,
              legalName: company.legal_name,
            },
          }
        );

        if (enrichError) {
          console.error(`Error enriching ${company.name}:`, enrichError);
          await supabase
            .from('companies')
            .update({ enrichment_status: 'failed' })
            .eq('id', company.id);
          continue;
        }

        // Update company with enriched data
        const updateData = {
          ...enrichData.data,
          enrichment_status: 'completed',
          last_enriched_at: new Date().toISOString(),
        };

        await supabase
          .from('companies')
          .update(updateData)
          .eq('id', company.id);

        // Small delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      toast({
        title: "Enrichment complete",
        description: `Successfully enriched ${companies.length} companies`,
      });
      onRefresh();
    } catch (error) {
      console.error('Error during enrichment:', error);
      toast({
        title: "Error",
        description: "Failed to complete enrichment process",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
      setProgress(0);
      setCurrentCompany("");
    }
  };

  const exportToCsv = async () => {
    try {
      const { data: companies, error } = await supabase
        .from('companies')
        .select('*')
        .order('name');

      if (error) throw error;

      const headers = [
        'id', 'name', 'legal_name', 'website', 'headquarters_city', 'founded_year',
        'employee_count', 'annual_revenue_usd', 'financing_volume_usd', 'market_share_percentage',
        'business_model', 'financing_types', 'credit_requirements', 'avg_approval_rate',
        'avg_interest_rate', 'max_financing_amount_usd', 'avg_term_months', 'status',
        'created_at', 'updated_at'
      ];

      const csvContent = [
        headers.join(','),
        ...companies.map(company =>
          headers.map(header => {
            let value = company[header];
            if (Array.isArray(value)) {
              value = `"${value.join(';')}"`;
            } else if (value === null || value === undefined) {
              value = '';
            } else if (typeof value === 'string' && value.includes(',')) {
              value = `"${value}"`;
            }
            return value;
          }).join(',')
        )
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `enriched_companies_${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);

      toast({
        title: "Export successful",
        description: "Enriched data has been downloaded",
      });
    } catch (error) {
      console.error('Error exporting CSV:', error);
      toast({
        title: "Error",
        description: "Failed to export data",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="p-6 shadow-lg">
      <div className="space-y-4">
        <div className="flex flex-wrap gap-3">
          <Button onClick={loadCsvData} variant="outline" className="gap-2">
            <Upload className="w-4 h-4" />
            Load CSV Data
          </Button>
          <Button
            onClick={enrichAllCompanies}
            disabled={processing}
            className="gap-2 bg-gradient-to-r from-primary to-primary/80"
          >
            <Play className="w-4 h-4" />
            {processing ? 'Processing...' : 'Start Enrichment'}
          </Button>
          <Button onClick={exportToCsv} variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            Export CSV
          </Button>
          <Button onClick={onRefresh} variant="ghost" className="gap-2">
            <RefreshCw className="w-4 h-4" />
            Refresh
          </Button>
        </div>

        {processing && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Processing: {currentCompany}</span>
              <span className="font-medium">{progress.toFixed(0)}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        )}
      </div>
    </Card>
  );
};