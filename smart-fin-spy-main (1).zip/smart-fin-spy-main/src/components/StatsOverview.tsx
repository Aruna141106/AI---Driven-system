import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { Database, CheckCircle2, Clock, TrendingUp } from "lucide-react";

export const StatsOverview = ({ refreshKey }: { refreshKey: number }) => {
  const [stats, setStats] = useState({
    total: 0,
    completed: 0,
    pending: 0,
    avgConfidence: 0,
  });

  useEffect(() => {
    loadStats();
  }, [refreshKey]);

  const loadStats = async () => {
    try {
      const { data: companies } = await supabase
        .from('companies')
        .select('enrichment_status, confidence_score');

      if (!companies) return;

      const total = companies.length;
      const completed = companies.filter(c => c.enrichment_status === 'completed').length;
      const pending = companies.filter(
        c => !c.enrichment_status || c.enrichment_status === 'pending'
      ).length;
      
      const confidenceScores = companies
        .filter(c => c.confidence_score !== null)
        .map(c => c.confidence_score as number);
      
      const avgConfidence = confidenceScores.length > 0
        ? confidenceScores.reduce((a, b) => a + b, 0) / confidenceScores.length
        : 0;

      setStats({ total, completed, pending, avgConfidence });
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  };

  const statCards = [
    {
      label: 'Total Companies',
      value: stats.total,
      icon: Database,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
    {
      label: 'Enriched',
      value: stats.completed,
      icon: CheckCircle2,
      color: 'text-accent',
      bgColor: 'bg-accent/10',
    },
    {
      label: 'Pending',
      value: stats.pending,
      icon: Clock,
      color: 'text-muted-foreground',
      bgColor: 'bg-muted',
    },
    {
      label: 'Avg Confidence',
      value: `${stats.avgConfidence.toFixed(0)}%`,
      icon: TrendingUp,
      color: 'text-accent',
      bgColor: 'bg-accent/10',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {statCards.map((stat, idx) => (
        <Card key={idx} className="p-6 shadow-md hover:shadow-lg transition-shadow">
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-lg ${stat.bgColor}`}>
              <stat.icon className={`w-6 h-6 ${stat.color}`} />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
              <p className="text-2xl font-bold">{stat.value}</p>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
};