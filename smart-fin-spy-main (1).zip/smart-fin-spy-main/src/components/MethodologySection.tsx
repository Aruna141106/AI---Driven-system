import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

export const MethodologySection = () => {
  return (
    <Card className="p-6 shadow-lg">
      <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
        <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
          System Methodology
        </span>
      </h2>

      <Tabs defaultValue="architecture" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="architecture">Architecture</TabsTrigger>
          <TabsTrigger value="extraction">AI Extraction</TabsTrigger>
          <TabsTrigger value="confidence">Quality</TabsTrigger>
          <TabsTrigger value="schema">Schema</TabsTrigger>
          <TabsTrigger value="scalability">Scalability</TabsTrigger>
        </TabsList>

        <TabsContent value="architecture" className="space-y-4">
          <h3 className="text-lg font-semibold">System Architecture</h3>
          <div className="prose prose-sm max-w-none text-muted-foreground space-y-3">
            <p>
              The system uses a <Badge variant="secondary">cloud-native architecture</Badge> with the following components:
            </p>
            <ul className="list-disc list-inside space-y-2">
              <li><strong>Frontend:</strong> React-based UI for data visualization and control</li>
              <li><strong>Backend:</strong> Serverless edge functions for scalable processing</li>
              <li><strong>Database:</strong> PostgreSQL with real-time capabilities</li>
              <li><strong>AI Layer:</strong> Google Gemini 2.5 Flash for intelligent extraction</li>
              <li><strong>Pipeline:</strong> Automated enrichment workflow with error handling</li>
            </ul>
            <p>
              The architecture supports <strong>parallel processing</strong>, automatic retries, and maintains
              complete audit trails for all enrichment operations.
            </p>
          </div>
        </TabsContent>

        <TabsContent value="extraction" className="space-y-4">
          <h3 className="text-lg font-semibold">AI Extraction Approach</h3>
          <div className="prose prose-sm max-w-none text-muted-foreground space-y-3">
            <p>
              We employ a <Badge variant="secondary">multi-stage AI extraction</Badge> process:
            </p>
            <ul className="list-disc list-inside space-y-2">
              <li><strong>Web Research:</strong> AI-powered web search aggregates information from multiple sources</li>
              <li><strong>Structured Extraction:</strong> Tool calling forces structured JSON output with defined schemas</li>
              <li><strong>Pattern Recognition:</strong> LLM identifies business models, financing types, and market positioning</li>
              <li><strong>Entity Resolution:</strong> Cross-references company names, legal entities, and brands</li>
              <li><strong>Numerical Inference:</strong> Estimates financial metrics from available public data</li>
            </ul>
            <p>
              The system uses <strong>Google Gemini 2.5 Flash</strong> for optimal balance of speed, cost, and accuracy.
              Tool calling ensures consistent, validated output matching our database schema.
            </p>
          </div>
        </TabsContent>

        <TabsContent value="confidence" className="space-y-4">
          <h3 className="text-lg font-semibold">Confidence & Quality Assurance</h3>
          <div className="prose prose-sm max-w-none text-muted-foreground space-y-3">
            <p>
              Data quality is ensured through <Badge variant="secondary">multi-layer validation</Badge>:
            </p>
            <ul className="list-disc list-inside space-y-2">
              <li><strong>Confidence Scoring:</strong> AI assigns 0-100% confidence based on data availability and source quality</li>
              <li><strong>Source Attribution:</strong> All data points tracked to their original sources</li>
              <li><strong>Type Validation:</strong> Schema enforcement prevents invalid data types</li>
              <li><strong>Null Handling:</strong> Explicit null values for missing data (no fabrication)</li>
              <li><strong>Manual Review:</strong> Low-confidence entries flagged for human verification</li>
            </ul>
            <p>
              The AI is instructed to <strong>never hallucinate</strong> - if information isn't found,
              fields remain null rather than being estimated without basis.
            </p>
          </div>
        </TabsContent>

        <TabsContent value="schema" className="space-y-4">
          <h3 className="text-lg font-semibold">Schema Materialization</h3>
          <div className="prose prose-sm max-w-none text-muted-foreground space-y-3">
            <p>
              Data normalization and storage follows <Badge variant="secondary">strict schema rules</Badge>:
            </p>
            <ul className="list-disc list-inside space-y-2">
              <li><strong>Type Safety:</strong> PostgreSQL enforces INTEGER, NUMERIC, TEXT, and ARRAY types</li>
              <li><strong>Normalization:</strong> Arrays for multi-value fields (financing types), controlled vocabularies</li>
              <li><strong>Audit Trail:</strong> Created/updated timestamps, enrichment status tracking</li>
              <li><strong>Validation Triggers:</strong> Database-level constraints ensure data integrity</li>
              <li><strong>Versioning:</strong> Enrichment history maintained for rollback capabilities</li>
            </ul>
            <p>
              All enriched data is <strong>immediately persisted</strong> to the database with full ACID
              guarantees, preventing data loss during processing.
            </p>
          </div>
        </TabsContent>

        <TabsContent value="scalability" className="space-y-4">
          <h3 className="text-lg font-semibold">Scalability & Ethics</h3>
          <div className="prose prose-sm max-w-none text-muted-foreground space-y-3">
            <p>
              The system is designed for <Badge variant="secondary">enterprise-scale deployment</Badge>:
            </p>
            <ul className="list-disc list-inside space-y-2">
              <li><strong>Horizontal Scaling:</strong> Serverless functions auto-scale with demand</li>
              <li><strong>Rate Limiting:</strong> Automatic throttling prevents API abuse</li>
              <li><strong>Error Handling:</strong> Graceful degradation with retry logic</li>
              <li><strong>Cost Optimization:</strong> Efficient model selection balances speed and cost</li>
              <li><strong>Public Data Only:</strong> All information sourced from publicly available data</li>
              <li><strong>Privacy Compliance:</strong> No personal data collection, GDPR/POPIA aligned</li>
              <li><strong>Attribution:</strong> Source tracking enables verification and compliance</li>
            </ul>
            <p>
              The platform can process <strong>thousands of companies</strong> with parallel execution,
              while maintaining ethical data sourcing and clear provenance tracking.
            </p>
          </div>
        </TabsContent>
      </Tabs>
    </Card>
  );
};