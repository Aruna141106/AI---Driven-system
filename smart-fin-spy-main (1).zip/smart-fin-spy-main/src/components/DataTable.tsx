import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Company {
  id: string;
  name: string;
  legal_name: string | null;
  website: string | null;
  headquarters_city: string | null;
  founded_year: number | null;
  business_model: string | null;
  financing_types: string[] | null;
  enrichment_status: string | null;
  confidence_score: number | null;
}

export const DataTable = ({ refreshKey }: { refreshKey: number }) => {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCompanies();
  }, [refreshKey]);

  const loadCompanies = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .order('name');

      if (error) throw error;
      setCompanies(data || []);
    } catch (error) {
      console.error('Error loading companies:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="p-6">
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg">
      <ScrollArea className="h-[600px]">
        <Table>
          <TableHeader className="sticky top-0 bg-card z-10">
            <TableRow>
              <TableHead className="font-semibold">Company Name</TableHead>
              <TableHead className="font-semibold">Legal Name</TableHead>
              <TableHead className="font-semibold">Website</TableHead>
              <TableHead className="font-semibold">HQ City</TableHead>
              <TableHead className="font-semibold">Founded</TableHead>
              <TableHead className="font-semibold">Business Model</TableHead>
              <TableHead className="font-semibold">Financing Types</TableHead>
              <TableHead className="font-semibold">Status</TableHead>
              <TableHead className="font-semibold">Confidence</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {companies.map((company) => (
              <TableRow key={company.id} className="hover:bg-muted/50 transition-colors">
                <TableCell className="font-medium">{company.name}</TableCell>
                <TableCell className="text-muted-foreground">{company.legal_name || '-'}</TableCell>
                <TableCell>
                  {company.website ? (
                    <a
                      href={company.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline text-sm"
                    >
                      Visit
                    </a>
                  ) : (
                    '-'
                  )}
                </TableCell>
                <TableCell>{company.headquarters_city || '-'}</TableCell>
                <TableCell>{company.founded_year || '-'}</TableCell>
                <TableCell className="max-w-xs truncate">{company.business_model || '-'}</TableCell>
                <TableCell>
                  {company.financing_types && company.financing_types.length > 0 ? (
                    <div className="flex flex-wrap gap-1">
                      {company.financing_types.slice(0, 2).map((type, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {type}
                        </Badge>
                      ))}
                      {company.financing_types.length > 2 && (
                        <Badge variant="secondary" className="text-xs">
                          +{company.financing_types.length - 2}
                        </Badge>
                      )}
                    </div>
                  ) : (
                    '-'
                  )}
                </TableCell>
                <TableCell>
                  <Badge
                    variant={
                      company.enrichment_status === 'completed'
                        ? 'default'
                        : company.enrichment_status === 'processing'
                        ? 'outline'
                        : 'secondary'
                    }
                  >
                    {company.enrichment_status || 'pending'}
                  </Badge>
                </TableCell>
                <TableCell>
                  {company.confidence_score ? (
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-secondary rounded-full h-2">
                        <div
                          className="bg-accent h-2 rounded-full transition-all"
                          style={{ width: `${company.confidence_score}%` }}
                        />
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {company.confidence_score.toFixed(0)}%
                      </span>
                    </div>
                  ) : (
                    '-'
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </ScrollArea>
    </Card>
  );
};