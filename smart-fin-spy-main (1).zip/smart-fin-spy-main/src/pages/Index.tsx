import { useState } from "react";
import { DataTable } from "@/components/DataTable";
import { EnrichmentControls } from "@/components/EnrichmentControls";
import { MethodologySection } from "@/components/MethodologySection";
import { StatsOverview } from "@/components/StatsOverview";

const Index = () => {
  const [refreshKey, setRefreshKey] = useState(0);

  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      </div>
      
      <div className="container mx-auto py-12 px-4 space-y-12 relative z-10">
        {/* Header */}
        <header className="text-center space-y-6 animate-fade-in">
          <h1 className="text-6xl md:text-7xl font-bold bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent animate-gradient bg-[length:200%_auto]">
            AI-Powered Data Enrichment
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Automated intelligence extraction for smartphone financing companies in South Africa
          </p>
          <div className="flex gap-2 justify-center items-center text-sm text-muted-foreground">
            <div className="w-2 h-2 rounded-full bg-accent animate-pulse"></div>
            <span>Powered by Advanced AI Models</span>
          </div>
        </header>

        {/* Stats Overview */}
        <StatsOverview refreshKey={refreshKey} />

        {/* Enrichment Controls */}
        <EnrichmentControls onRefresh={handleRefresh} />

        {/* Data Table */}
        <DataTable refreshKey={refreshKey} />

        {/* Methodology */}
        <MethodologySection />
      </div>
    </div>
  );
};

export default Index;